<!doctype html>
<html lang="en">

<link rel="stylesheet" href="/app.css">

<title>Document</title>

<body>

<?php echo e($slot); ?>



</body>
</html>
<?php /**PATH /var/www/laravel/yourproject.com/resources/views/components/layout.blade.php ENDPATH**/ ?>