<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/app.css">
    <title>Document</title>
</head>
<body>
<article>
    <?=$post;?>


<a href="/"> Go Back</a>
        </article>
</body>
</html>
<?php /**PATH /var/www/laravel/yourproject.com/resources/views/post.blade.php ENDPATH**/ ?>