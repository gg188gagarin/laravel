<!doctype html>
<html lang="en">

<link rel="stylesheet" href="/app.css">

<title>Document</title>

<body>

{{$slot}}


</body>
</html>
